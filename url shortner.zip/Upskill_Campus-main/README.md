# Upskill_Campus
The URL Shortener project aims to develop a Python-based application that converts long URLs into shorter, more manageable links. This progress report outlines the accomplishments made during the first week of the project, focusing on project initiation, environment setup, and preliminary research.
